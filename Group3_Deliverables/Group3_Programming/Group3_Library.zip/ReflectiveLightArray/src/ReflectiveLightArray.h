#ifndef REFLECTIVELIGHTARRAY_H
#define REFLECTIVELIGHTARRAY_H

class ReflectiveLightArray {
public:  
    int* pins;
    int numSensors;
    int* sensorValues;

    ReflectiveLightArray(int* sensorPins, int sensorCount); //constructor

    void begin(); //initialize pins
    void update(); //update sensor values

    int getSensorValue(int index); //get value of a specific sensor

    int* getSensorValues();// get values of all sensors as an array

    void printValues();// print sensor values to serial monityor
};

#endif // REFLECTIVELIGHTARRAY_H
