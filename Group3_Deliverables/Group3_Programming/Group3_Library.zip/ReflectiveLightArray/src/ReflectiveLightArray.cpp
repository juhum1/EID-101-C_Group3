#include "ReflectiveLightArray.h"
#include "Arduino.h"

// constructor
ReflectiveLightArray::ReflectiveLightArray(int* sensorPins, int sensorCount) {
    numSensors = sensorCount;
    pins = new int[numSensors];
    sensorValues = new int[numSensors];

    for (int i = 0; i < numSensors; i++) {
        pins[i] = sensorPins[i];
    }
}

// initializing pins for input
void ReflectiveLightArray::begin() {
    for (int i = 0; i < numSensors; i++) {
        pinMode(pins[i], INPUT);
    }
}

// updating array of sensor values
void ReflectiveLightArray::update() {
    for (int i = 0; i < numSensors; i++) {
        sensorValues[i] = analogRead(pins[i]);
    }
}

// getting values of a specific sensor
int ReflectiveLightArray::getSensorValue(int index) {
    if (index < numSensors) {
        return sensorValues[index]; 
    } else {
        return -1; // if the index is invalid
    }
}

// getting array of sensor values
int* ReflectiveLightArray::getSensorValues() {
    return sensorValues;
}

// printing sensor values to serial monitor
void ReflectiveLightArray::printValues() {
    for (int i = 0; i < numSensors; i++) {
        Serial.print("Sensor ");
        Serial.print(i);
        Serial.print(": ");
        Serial.println(sensorValues[i]);
    }
}
